from decimal import Decimal, ROUND_HALF_UP


def round_currency(value: Decimal) -> Decimal:
    """Στρογγύλεμα σε δύο δεκαδικά ψηφία."""
    return value.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)

def convert_foreign_currency(amount: Decimal, exchange_rate: Decimal) -> Decimal:
    """Μετατροπή ξένου νομίσματος σε EUR με στρογγύλεμα."""
    return round_currency(amount * exchange_rate)

def calculate_declared_cost(corporate_payments: Decimal, traveler_expenses: Decimal) -> Decimal:
    """Υπολογισμός συνολικού δηλωμένου κόστους."""
    return round_currency(corporate_payments + traveler_expenses)

def calculate_approved_cost(declared_cost: Decimal, rejected_traveler_expense: Decimal) -> Decimal:
    """Υπολογισμός εγκεκριμένου κόστους μετά από απορρίψεις."""
    return round_currency(declared_cost - rejected_traveler_expense)

def calculate_traveler_balance(
    approved_traveler_expenses: Decimal, 
    advances: Decimal, 
    already_paid_refunds: Decimal
) -> Decimal:
    """
    Υπόλοιπο ταξιδιώτη = εγκεκριμένες δαπάνες που πλήρωσε ο ταξιδιώτης 
    − προκαταβολές − ήδη καταβληθείσες επιστροφές.
    """
    return round_currency(approved_traveler_expenses - advances - already_paid_refunds)

def calculate_trip_totals(trip):
    """
    Υπολογίζει τα οικονομικά μεγέθη ενός ταξιδιού βάσει των εξόδων και προκαταβολών.
    """
    expenses = trip.expenses.filter(is_active=True)
    
    # 1. Συνολικό Δηλωμένο (Corporate Paid + Traveler Paid ή άθροισμα ποσών)
    total_declared = sum((exp.corporate_paid + exp.traveler_paid) for exp in expenses)
    
    # 2. Εγκεκριμένο Κόστος (Μόνο τα έξοδα με status == 'APPROVED')
    approved_expenses = expenses.filter(status='APPROVED')
    total_approved = sum((exp.corporate_paid + exp.traveler_paid) for exp in approved_expenses)
    
    # 3. Συνολικές Προκαταβολές
    total_advances = sum(adv.amount for adv in trip.advances.all())
    
    # 4. Υπόλοιπο / Ισοζύγιο (π.χ. Εγκεκριμένα - Προκαταβολές ή Επιστροφή)
    # Αν τα εταιρικώς πληρωμένα καλύπτουν μέρος, υπολογίζουμε τι οφείλεται ή επιστρέφεται.
    # Σύμφωνα με το παράδειγμα: Επιστροφή = Traveler Paid εγκεκριμένα - Προκαταβολές (ή ανάλογη λογική)
    traveler_approved_paid = sum(exp.traveler_paid for exp in approved_expenses)
    balance = traveler_approved_paid - total_advances
    
    return {
        'total_declared': round(total_declared, 2),
        'total_approved': round(total_approved, 2),
        'total_advances': round(total_advances, 2),
        'balance': round(balance, 2),
    }