from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from .models import Trip, Expense, AdvancePayment
from django import forms
from .forms import ExpenseForm, AdvancePaymentForm, TripForm
from .calculators import calculate_trip_totals

@login_required
def trip_list(request):
    """Εμφάνιση λίστας ταξιδιών του συνδεδεμένου χρήστη"""
    if request.user.is_superuser or getattr(request.user, 'role', '') == 'manager':
        trips = Trip.objects.filter(is_active=True)
    else:
        trips = Trip.objects.filter(traveler=request.user, is_active=True)
    
    return render(request, 'trips/trip_list.html', {'trips': trips})

@login_required
def trip_detail(request, pk):
    """Αναλυτική προβολή ταξιδιού με τα έξοδα και τους υπολογισμούς τους"""
    trip = get_object_or_404(Trip, pk=pk)
    totals = calculate_trip_totals(trip)
    
    total_declared = trip.get_total_declared()
    total_approved = trip.get_total_approved()
    total_advances = trip.get_total_advances()
    balance = total_approved - total_advances

    context = {
        'trip': trip,
        'totals': totals,
        'total_declared': total_declared,
        'total_approved': total_approved,
        'total_advances': total_advances,
        'balance': balance,
    }
    return render(request, 'trips/trip_detail.html', context)

@login_required
def add_expense(request, trip_pk):
    """Προσθήκη νέου εξόδου σε συγκεκριμένο ταξίδι"""
    trip = get_object_or_404(Trip, pk=trip_pk)
    
    if request.method == 'POST':
        form = ExpenseForm(request.POST)
        if form.is_valid():
            expense = form.save(commit=False)
            expense.trip = trip
            expense.save()
            return redirect('trips:trip_detail', pk=trip.pk)
    else:
        form = ExpenseForm()
    
    return render(request, 'trips/add_expense.html', {'form': form, 'trip': trip})

@login_required
def add_advance(request, trip_pk):
    """Προσθήκη προκαταβολής σε συγκεκριμένο ταξίδι"""
    trip = get_object_or_404(Trip, pk=trip_pk)
    
    if request.method == 'POST':
        form = AdvancePaymentForm(request.POST)
        if form.is_valid():
            advance = form.save(commit=False)
            advance.trip = trip
            advance.save()
            return redirect('trips:trip_detail', pk=trip.pk)
    else:
        form = AdvancePaymentForm()
    
    return render(request, 'trips/add_advance.html', {'form': form, 'trip': trip})
# --- Views για Έξοδα ---

def expense_edit(request, pk):
    expense = get_object_or_404(Expense, pk=pk)
    trip_pk = expense.trip.pk
    if request.method == 'POST':
        form = ExpenseForm(request.POST, instance=expense)
        if form.is_valid():
            form.save()
            return redirect('trips:trip_detail', pk=trip_pk)
    else:
        form = ExpenseForm(instance=expense)
    
    return render(request, 'trips/add_expense.html', {'form': form, 'trip': expense.trip})

def expense_delete(request, pk):
    expense = get_object_or_404(Expense, pk=pk)
    trip_pk = expense.trip.pk
    if request.method == 'POST':
        expense.delete()
        return redirect('trips:trip_detail', pk=trip_pk)
    return render(request, 'trips/expense_confirm_delete.html', {'expense': expense})


# --- Views για Προκαταβολές ---

def advance_edit(request, pk):
    advance = get_object_or_404(AdvancePayment, pk=pk)
    trip_pk = advance.trip.pk
    if request.method == 'POST':
        form = AdvancePaymentForm(request.POST, instance=advance)
        if form.is_valid():
            form.save()
            return redirect('trips:trip_detail', pk=trip_pk)
    else:
        form = AdvancePaymentForm(instance=advance)
        
    return render(request, 'trips/add_advance.html', {'form': form, 'trip': advance.trip})

def advance_delete(request, pk):
    advance = get_object_or_404(AdvancePayment, pk=pk)
    trip_pk = advance.trip.pk
    if request.method == 'POST':
        advance.delete()
        return redirect('trips:trip_detail', pk=trip_pk)
    return render(request, 'trips/advance_confirm_delete.html', {'advance': advance})

def expense_approve(request, pk):
    expense = get_object_or_404(Expense, pk=pk)
    expense.status = 'APPROVED'
    expense.is_approved = True
    expense.save()
    return redirect('trips:trip_detail', pk=expense.trip.pk)

def expense_reject(request, pk):
    expense = get_object_or_404(Expense, pk=pk)
    expense.status = 'REJECTED'
    expense.is_approved = False
    expense.save()
    return redirect('trips:trip_detail', pk=expense.trip.pk)

def add_trip(request):
    if request.method == 'POST':
        form = TripForm(request.POST)
        if form.is_valid():
            trip = form.save()
            return redirect('trips:trip_detail', pk=trip.pk)
    else:
        form = TripForm()
    
    return render(request, 'trips/add_trip.html', {'form': form})

