import unittest
from decimal import Decimal
from trips.calculators import (
    calculate_declared_cost,
    calculate_approved_cost,
    calculate_traveler_balance,
    round_currency
)

class TestTripCalculators(unittest.TestCase):
    
    def test_acceptance_numbers(self):
        # Δεδομένα από το παράδειγμα αποδοχής της προδιαγραφής
        corporate_payments = Decimal('610.77')  #
        traveler_expenses = Decimal('105.55')   #
        rejected_expense = Decimal('14.30')     #[cite: 1]
        advance = Decimal('50.00')              #[cite: 1]
        already_paid = Decimal('0.00')
        
        # 1. Δηλωμένο κόστος: 610,77 + 105,55 = 716,32
        declared = calculate_declared_cost(corporate_payments, traveler_expenses)
        self.assertEqual(declared, Decimal('716.32'))  #[cite: 1]
        
        # 2. Εγκεκριμένο κόστος: 716,32 - 14,30 = 702,02
        approved = calculate_approved_cost(declared, rejected_expense)
        self.assertEqual(approved, Decimal('702.02'))  #[cite: 1]
        
        # 3. Εγκεκριμένα έξοδα ταξιδιώτη καθαρά (χωρίς την απόρριψη των 14,30)
        approved_traveler_net = traveler_expenses - rejected_expense  # 105.55 - 14.30 = 91.25[cite: 1]
        self.assertEqual(approved_traveler_net, Decimal('91.25'))  #[cite: 1]
        
        # 4. Υπόλοιπο ταξιδιώτη: 91,25 - 50,00 (προκαταβολή) = 41,25
        balance = calculate_traveler_balance(approved_traveler_net, advance, already_paid)
        self.assertEqual(balance, Decimal('41.25'))  #[cite: 1]

if __name__ == '__main__':
    unittest.main()